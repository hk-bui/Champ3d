% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function hi_loadsolution()
callfemm('hi_loadsolution()');

