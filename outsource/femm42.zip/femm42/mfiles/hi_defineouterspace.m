% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function hi_defineouterspace(Zo,Ro,Ri)
callfemm(['hi_defineouterspace(' , numc(Zo) , numc(Ro) , num(Ri) , ')' ]);

