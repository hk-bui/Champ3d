% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ei_defineouterspace(Zo,Ro,Ri)
callfemm(['ei_defineouterspace(' , numc(Zo) , numc(Ro) , num(Ri) , ')' ]);

