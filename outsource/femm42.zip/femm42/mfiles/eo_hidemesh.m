% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function eo_hidemesh()
callfemm('eo_hidemesh()');

