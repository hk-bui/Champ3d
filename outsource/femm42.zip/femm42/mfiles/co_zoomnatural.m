% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_zoomnatural()
callfemm('co_zoomnatural()');

