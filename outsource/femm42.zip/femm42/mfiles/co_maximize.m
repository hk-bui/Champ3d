% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_maximize()
	callfemm('co_maximize()');

