% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ho_showgrid()
callfemm('ho_showgrid()');

