% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function dia=IEC(iec)
dia=7.959159641581004*exp(-0.11519673572274754*iec);

