% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function eo_showcontourplot(numcontours,al,au)
callfemm(['eo_showcontourplot(' , numc(numcontours) , numc(al) , num(au) , ')' ]);

