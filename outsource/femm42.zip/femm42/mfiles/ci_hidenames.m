% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ci_hidenames()
callfemm('ci_shownames(0)');

