% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_hidenames()
callfemm('co_shownames(0)');

