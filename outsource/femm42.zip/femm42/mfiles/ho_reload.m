% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ho_reload()
callfemm('ho_reload()');

