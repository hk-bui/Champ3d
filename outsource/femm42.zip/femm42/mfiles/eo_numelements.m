% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function z=eo_numelements()
z=callfemm('eo_numelements()');

