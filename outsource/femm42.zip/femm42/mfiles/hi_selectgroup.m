% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function hi_selectgroup(gr)
callfemm(['hi_selectgroup(' , num(gr) , ')' ]);

