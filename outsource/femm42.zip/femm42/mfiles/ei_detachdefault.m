% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ei_detachdefault()
callfemm('ei_detachdefault()');

