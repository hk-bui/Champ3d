% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function eo_zoomout()
callfemm('eo_zoomout()');

