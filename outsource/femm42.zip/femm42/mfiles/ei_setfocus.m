% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ei_setfocus(docname)
callfemm(['ei_setfocus(' , quote(docname) , ')' ]);

