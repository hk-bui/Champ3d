% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ho_seteditmode(mode)
callfemm(['ho_seteditmode(' , quote(mode) , ')' ]);

