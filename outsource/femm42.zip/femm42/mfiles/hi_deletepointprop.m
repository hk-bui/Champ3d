% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function hi_deletepointprop(n)
callfemm(['hi_deletepointprop(' , quote(n) , ')' ]);

