% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_savebitmap(fn)
callfemm(['co_savebitmap(' , quote(fn) , ')' ]);

