% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function hi_savemetafile(n)
callfemm(['hi_savemetafile(' , quote(n) , ')' ]);

