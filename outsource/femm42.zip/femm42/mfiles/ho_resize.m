% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ho_resize(nWidth,nHeight)
	callfemm(['ho_resize(', numc(nWidth), num(nHeight), ')' ]);


