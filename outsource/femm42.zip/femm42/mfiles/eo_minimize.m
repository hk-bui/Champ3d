% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function eo_minimize()
	callfemm('eo_minimize()');

