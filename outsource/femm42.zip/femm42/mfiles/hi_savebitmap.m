% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function hi_savebitmap(n)
callfemm(['hi_savebitmap(' , quote(n) , ')' ]);

