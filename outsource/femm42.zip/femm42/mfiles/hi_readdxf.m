% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function hi_readdxf(docname)
callfemm(['print(hi_readdxf(' , quote(docname) , '))' ]);

