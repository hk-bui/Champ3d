% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_savemetafile(fn)
callfemm(['co_savemetafile(' , quote(fn) , ')' ]);

