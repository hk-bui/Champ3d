% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ei_readdxf(docname)
callfemm(['print(ei_readdxf(' , quote(docname) , '))' ]);

