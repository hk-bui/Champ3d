% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function z=co_getprobleminfo()
z=callfemm('co_getprobleminfo()');

