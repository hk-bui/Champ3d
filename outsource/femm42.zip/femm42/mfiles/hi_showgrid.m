% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function hi_showgrid()
callfemm('hi_showgrid()');

