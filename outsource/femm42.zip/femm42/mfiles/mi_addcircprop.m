% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function mi_addcircprop(pname,ic,ptype)
callfemm(['mi_addcircprop(' , quotec(pname) , numc(ic) , num(ptype) , ')' ]);

