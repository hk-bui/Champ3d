% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ei_deletepointprop(n)
callfemm(['ei_deletepointprop(' , quote(n) , ')' ]);

