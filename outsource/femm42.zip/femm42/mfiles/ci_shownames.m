% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ci_shownames()
callfemm('ci_shownames(1)');

