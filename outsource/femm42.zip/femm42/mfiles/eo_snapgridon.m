% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function eo_snapgridon()
callfemm('eo_gridsnap("on")');

