% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ei_saveas(fn)
callfemm(['ei_saveas(' , quote(fn) , ')']);

