% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function eo_shownames()
callfemm('eo_shownames(1)');

