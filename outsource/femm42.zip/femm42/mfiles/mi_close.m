% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function mi_close()
callfemm('mi_close()');

