% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function eo_savemetafile(fn)
callfemm(['eo_savemetafile(' , quote(fn) , ')' ]);

