% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ci_restore()
	callfemm('ci_restore()');

