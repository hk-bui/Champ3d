% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function z=eo_numnodes()
z=callfemm('eo_numnodes()');

