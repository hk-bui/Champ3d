% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function main_resize(nWidth,nHeight)
	callfemm(['main_resize(', numc(nWidth), num(nHeight), ')' ]);

