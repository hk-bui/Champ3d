% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function mi_attachdefault()
callfemm('mi_attachdefault()');

