% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function z=ho_numelements()
z=callfemm('ho_numelements()');

