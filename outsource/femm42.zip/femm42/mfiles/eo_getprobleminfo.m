% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function z=eo_getprobleminfo()
z=callfemm('eo_getprobleminfo()');

