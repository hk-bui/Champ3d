% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_bendcontour(tta,dtta)
callfemm(['co_bendcontour(' , numc(tta) , num(dtta) , ')' ]);

