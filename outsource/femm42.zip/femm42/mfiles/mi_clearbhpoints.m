% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function mi_clearbhpoints(n)
callfemm(['mi_clearbhpoints(' , quote(n) , ')' ]);

