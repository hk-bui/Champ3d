% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function eo_hidecontourplot()
callfemm('eo_hidecontourplot()');

