% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_showmesh()
callfemm('co_showmesh()');

