% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function hi_savedxf(docname)
callfemm_noeval(['hi_savedxf(' , quote(docname) , ')' ]);

