% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ho_savebitmap(fn)
callfemm(['ho_savebitmap(' , quote(fn) , ')' ]);

