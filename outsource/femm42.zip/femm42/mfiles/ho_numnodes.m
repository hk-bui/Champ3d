% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function z=ho_numnodes()
z=callfemm('ho_numnodes()');

