% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function eo_showgrid()
callfemm('eo_showgrid()');

