% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ei_clearselected()
callfemm('ei_clearselected()');

