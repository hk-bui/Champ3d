% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ci_selectgroup(gr)
callfemm(['ci_selectgroup(' , num(gr) , ')' ]);

