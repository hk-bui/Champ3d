% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_close()
callfemm('co_close()');

