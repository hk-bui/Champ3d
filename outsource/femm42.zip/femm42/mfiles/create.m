% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function create(n)
callfemm([ 'create(' , num(n) , ')' ]);

