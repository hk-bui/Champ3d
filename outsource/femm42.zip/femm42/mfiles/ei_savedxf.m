% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ei_savedxf(docname)
callfemm_noeval(['ei_savedxf(' , quote(docname) , ')' ]);

