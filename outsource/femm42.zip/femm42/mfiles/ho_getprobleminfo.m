% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function z=ho_getprobleminfo()
z=callfemm('ho_getprobleminfo()');

