% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_hidemesh()
callfemm('co_hidemesh()');

