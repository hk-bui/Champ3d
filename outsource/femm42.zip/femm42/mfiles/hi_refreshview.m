% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function hi_refreshview()
callfemm('hi_refreshview()');

