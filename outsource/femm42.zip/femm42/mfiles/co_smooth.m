% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_smooth(flag)
callfemm(['co_smooth(' , quote(flag) , ')' ]);

