% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function hi_seteditmode(editmode)
callfemm(['hi_seteditmode(' , quote(editmode) , ')' ]);

