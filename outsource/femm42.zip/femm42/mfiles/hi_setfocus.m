% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function hi_setfocus(docname)
callfemm(['hi_setfocus(' , quote(docname) , ')' ]);

