% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function main_restore()
	callfemm('main_restore()');

